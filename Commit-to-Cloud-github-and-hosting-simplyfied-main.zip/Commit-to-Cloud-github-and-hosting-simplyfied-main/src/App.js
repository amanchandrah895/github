import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Peer-Mentor Learning Series Workshop 1</h1>
        <div className="user-info">
          <p><strong>Name:</strong> Your Name</p> 
          <p><strong>USN:</strong> Your USN</p>
        </div>
      </header>
    </div>
  );
}

export default App;
